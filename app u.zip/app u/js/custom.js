$('body').scrollspy({ target: '#navbarSupportedContent' });

 //animation scroll js

 $('.navbar-nav .nav-item .nav-link').on('click', function () {
  if (location.pathname.replace(/^\//, '') === this.pathname.replace(/^\//, '') && location.hostname === this.hostname) {
      var target = $(this.hash);
      target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
      if (target.length) {
          $('html, body').animate({
              scrollTop: target.offset().top - 0
          }, 1000);
          return false;
      }
  }
});

$(window).on('scroll' , function(){
  var $scrolling = $(this).scrollTop();
 
  if($scrolling > 130){
    $('#navigation').addClass("navfixed");
  }
  else{
    $('#navigation').removeClass("navfixed");
  }
});

$('.services_item').slick({
  infinite: true,
  slidesToShow: 3,
  slidesToScroll: 1,
    autoplay:true,
    autoplaySpeed:1000,
    vertical:true,
    nextArrow:false,
    prevArrow:false,
    verticalSwiping:true
});

$('.test-slide').slick({
        infinite: true,
        slidesToShow: 2,
        slidesToScroll: 1,
        dots: true,
        arrows: false,
        autoplay: true,
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 3,
                    infinite: true,
                    dots: true
                }
        },
            {
                breakpoint: 600,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2
                }
        },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
        }
        // You can unslick at a given breakpoint now by adding:
        // settings: "unslick"
        // instead of a settings object
      ]
    });

$('.counter').counterUp({
    delay: 10,
    time: 1000
});


// this is for back to top

    $(window).scroll(function(){
        var scrltop = $(this).scrollTop();
        if (scrltop > 330){
            $('.btm2top').fadeIn(), 500;
        }else{
            $('.btm2top').fadeOut(), 500;
        }
    });
	$('.btm2top').on('click', function () {
		$('html, Body').animate({
			scrollTop: 0
		}, 1300);
	});